
package Kernel;

/**
 * Centro de Estudios de Matemática Computacional(CEMC-UCI) 
 * @date 23-sep-2014
 * @author yadian
 */
public enum Notify {
    Error,
    Processing
}
