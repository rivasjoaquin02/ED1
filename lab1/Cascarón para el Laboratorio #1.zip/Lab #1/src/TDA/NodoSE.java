package TDA;

public class NodoSE<T>
{

    private T dato;
    private NodoSE<T> siguiente;

    public NodoSE(T dato, NodoSE<T> siguiente)
    {
        this.setDato(dato);
        this.setSiguiente(siguiente);
    }

    public void setDato(T dato)
    {
        this.dato = dato;
    }

    public T getDato()
    {
        return dato;
    }

    public void setSiguiente(NodoSE<T> sgte)
    {
        this.siguiente = sgte;
    }

    public NodoSE<T> getSiguiente()
    {
        return siguiente;
    }

}
