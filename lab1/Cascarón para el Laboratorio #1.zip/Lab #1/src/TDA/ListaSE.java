package TDA;

/**
 * Centro de Estudios de Matemática Computacional(CEMC-UCI)
 *
 * @date 22-sep-2014
 * @author yadian
 */
import java.util.logging.Level;
import java.util.logging.Logger;

public class ListaSE<T extends Comparable> implements ILista<T>
{

    NodoSE<T> cabeza;

    public ListaSE()
    {
        cabeza = null;
    }

    /*
     Ejercicio 1.
         asdasdasda   
     */
    @Override
    public void Adicionar(T x) throws Exception
    {

        NodoSE<T> nodo = new NodoSE<T>(x, null);
        if (cabeza == null)
        {
            cabeza = nodo;
        } else
        {
            if (cabeza.getDato().compareTo(x) == -1)
            {
                nodo.setSiguiente(cabeza);
                cabeza = nodo;
                return;
            }
            NodoSE<T> cursor = cabeza;
            while (cursor.getSiguiente() != null)
            {
                if (cursor.getSiguiente().getDato().compareTo(x) == -1)
                {
                    nodo.setSiguiente(cursor.getSiguiente());
                    cursor.setSiguiente(nodo);
                    return;
                }
                cursor = cursor.getSiguiente();

            }
            cursor.setSiguiente(nodo);
        }

    }

    /*Ejercicio 2.
    
     */
    public T ObtenerPrimero() throws Exception
    {
        if (cabeza == null)
        {
            throw new Exception("La lista esta vacia");
        }
        T data = cabeza.getDato();
        cabeza = cabeza.getSiguiente();
        return data;
    }

    @Override
    public void Eliminar(int pos) throws Exception
    {
        if (cabeza == null)
        {
            throw new Exception("Lista vacía, la pos no existe");
        }
        if (!(pos >= 0 && pos < Longitud()))
        {
            throw new Exception("Pos fuera de rango");
        }
        if (pos == 0)
        {
            cabeza = cabeza.getSiguiente();
        } else
        {
            NodoSE<T> cursor = cabeza;
            int cont = 0;
            while (cont++ < pos - 1)
            {
                cursor = cursor.getSiguiente();
            }
            cursor.setSiguiente(cursor.getSiguiente().getSiguiente());

        }

    }

    @Override
    public void Insertar(T x, int pos) throws Exception
    {
        throw new Exception("Not Supported");
    }

    @Override
    public int Longitud()
    {
        if (cabeza == null)
        {
            return 0;
        } else
        {
            int longitud = 1;
            NodoSE<T> cursor = cabeza;
            while (cursor.getSiguiente() != null)
            {
                cursor = cursor.getSiguiente();
                longitud++;

            }
            return longitud;
        }
    }

    @Override
    public T Obtener(int pos) throws Exception
    {
        if (cabeza == null)
        {
            throw new Exception("Lista Vacía, la pos no existe");
        }
        if (pos < 0 && pos > Longitud() - 1)
        {
            throw new Exception("Posición fuera de rango");
        } else
        {
            NodoSE<T> cursor = cabeza;
            int cont = 0;
            while (cont++ < pos)
            {
                cursor = cursor.getSiguiente();

            }

            return cursor.getDato();
        }

    }

}
