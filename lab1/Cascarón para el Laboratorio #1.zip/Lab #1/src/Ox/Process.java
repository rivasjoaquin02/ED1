package Ox;

import Kernel.CemcOX;
import java.util.Observer;
import java.util.TimerTask;
import java.util.Timer;

/**
 * Centro de Estudios de Matemática Computacional(CEMC-UCI)
 *
 * @date 23-sep-2014
 * @author yadian
 */
public class Process implements Comparable<Process>
{

    private int id;//identificador
    private int Priority;//prioridad del proceso
    private int waitTime;//timepo de espera
    private boolean FirstTime;// es la primera ves que se ejecuta
    private Timer temp;//para tomoar el timepo(segundos)
    private Observer observer;
    private TimerTask tarea;

    public Process(int Priority, int id)
    {
        this.Priority = Priority;
        FirstTime = true;
        this.id = id;
        Play(true);
    }

    public int getPriority()
    {
        return Priority;
    }

    public int getWaitTime()
    {
        return waitTime;
    }

    public void execute()
    {
        temp.cancel();
        temp.purge();
        System.out.println(Priority + " - " + waitTime);
        notifyObserver();
    }

    public void setPriority(int Priority)
    {
        this.Priority = Priority;
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public boolean isFirstTime()
    {
        return FirstTime;
    }

    public void setFirstTime(boolean isFirstTime)
    {
        this.FirstTime = isFirstTime;
    }

    @Override
    public int compareTo(Process o)
    {
        if (o.getPriority() > Priority)
        {
            return -1;
        }
        if (o.getPriority() < Priority)
        {
            return 1;
        }
        return 0;
    }

    @Override
    public String toString()
    {
        return Priority + "";
    }

    private void notifyObserver()
    {
        if (observer != null)
        {
            observer.update(null, this);
        }
    }

    public void addObserver(Observer o)
    {
        observer = o;
    }

    public void Play(boolean play)
    {
        if (play)
        {
            tarea = new TimerTask()
            {
                @Override
                public void run()
                {
                    waitTime++;
                }
            };
            temp = new Timer();
            temp.schedule(tarea, 0, 1000);
        } else
        {
            temp.cancel();
            temp.purge();
        }

    }

}
