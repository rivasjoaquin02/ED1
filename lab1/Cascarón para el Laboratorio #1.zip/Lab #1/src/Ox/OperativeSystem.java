package Ox;

import TDA.ListaSE;

/**
 * Centro de Estudios de Matemática Computacional(CEMC-UCI)
 *
 * @date 24-sep-2014
 * @author yadian
 */
public class OperativeSystem
{

    public ListaSE<Process> procesos;

    public OperativeSystem()
    {
        procesos = new ListaSE<Process>();
    }

    public void newProcess(Process pp) throws Exception
    {
        synchronized (procesos)
        {
            procesos.Adicionar(pp);
        }
    }
    /*Ejercicio 2.*/
    /*
     adasdasdasdasdasdad
     */

    public void runProcess() throws Exception
    {
        Process mayor = procesos.Obtener(0);
        int pos = 0;
        for (int i = 1; i < procesos.Longitud(); i++)
        {
            if (procesos.Obtener(i).getWaitTime() > mayor.getWaitTime())
            {
                mayor = procesos.Obtener(i);
                pos = i;
            }
        }
        if (mayor.getWaitTime() > procesos.Obtener(0).getPriority())
        {
            mayor.execute();
            procesos.Eliminar(pos);

        } else
        {
            procesos.Obtener(0).execute();
            procesos.Eliminar(0);
        }
    }

    public int ProcessRequest()
    {
        return procesos.Longitud();
    }

    public Process getProcess(int i) throws Exception
    {
        return procesos.Obtener(i);
    }

    public ListaSE<Process> getALLProcess()
    {
        return procesos;
    }

}
