package Ox;

import TDA.ListaSE;

/**
 * Centro de Estudios de Matemática Computacional(CEMC-UCI)
 *
 * @author yadian
 * @date 24-sep-2014
 */
public class OperativeSystem {

    public ListaSE<Process> procesos;

    public OperativeSystem() {
        procesos = new ListaSE<Process>();
    }

    public void newProcess(Process pp) throws Exception {
        synchronized (procesos) {
            procesos.Adicionar(pp);
        }
    }
    /*Ejercicio 2.*/
    /*
     adasdasdasdasdasdad
     */

    // By STRANGE
    public void runProcess() throws Exception {
        // cojo el primero (sera el de mayor prioridad)
        Process maxProcess = procesos.Obtener(0);
        int p = 0;

        int i=0;
        for (Process pi: procesos){
            if (pi.getWaitTime() > maxProcess.getWaitTime()){
                maxProcess = pi;
                p = i;
            }
            i++;
        }
        maxProcess.execute();
        procesos.Eliminar(p);
    }

    public int ProcessRequest() {
        return procesos.Longitud();
    }

    public Process getProcess(int i) throws Exception {
        return procesos.Obtener(i);
    }

    public ListaSE<Process> getALLProcess() {
        return procesos;
    }

}
