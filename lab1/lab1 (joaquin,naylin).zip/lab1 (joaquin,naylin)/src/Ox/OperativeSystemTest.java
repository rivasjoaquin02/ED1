package Ox;

public class OperativeSystemTest {
    public static void main(String[] args) {
        runProcessTest();
    }

    private static void runProcessTest(){
        OperativeSystem linux = new OperativeSystem();

        Process t1 = new Process(5,1);
        t1.setWaitTime(20);
        Process t2 = new Process(4,2);
        t2.setWaitTime(30);


        try {
            linux.newProcess(t1);
            linux.newProcess(t2);
            linux.newProcess(new Process(6, 3));
            linux.newProcess(new Process(7, 4));
        } catch (Exception e){
            System.out.println(e.getMessage());
        }

        try {
            linux.runProcess();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
