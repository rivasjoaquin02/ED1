package Kernel;

import TDA.ListaSE;

import java.util.Observer;
import java.util.Random;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Centro de Estudios de Matemática Computacional(CEMC-UCI)
 *
 * @author yadian
 * @date 23-sep-2014
 */
public class ProcessGenerator extends Thread {

    private Random generator;
    private int interval;
    private Observer observer;
    private Semaphore repro;
    private boolean play;

    public ProcessGenerator(int interval) {
        this.interval = interval;
        generator = new Random();
        repro = new Semaphore(0);
        play = false;
    }

    public void setPlay(boolean play) {
        this.play = play;
        if (play)
            repro.release();
    }


    @Override
    public void run() {
        while (true) {
            try {
                if (!play)
                    repro.acquire();
                int num = generator.nextInt(40);
                notifyO(num);
                do {
                    interval = generator.nextInt(3000);
                } while (interval < 500);
                sleep(interval);
            } catch (InterruptedException ex) {
                Logger.getLogger(ProcessGenerator.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private void notifyO(int number) {
        if (observer != null) {
            observer.update(null, number);
        }
    }

    public void addObserver(Observer o) {
        observer = o;
    }

}
