package Kernel;

import TDA.ListaSE;

import java.util.Observer;
import java.util.Random;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.lang.model.type.NoType;

/**
 * Centro de Estudios de Matemática Computacional(CEMC-UCI)
 *
 * @author yadian
 * @date 23-sep-2014
 */
public class Processor extends Thread {

    private Observer observer;
    private Semaphore repro;
    private boolean play;

    public Processor() {

        repro = new Semaphore(0);
        play = false;
    }

    public void setPlay(boolean play) {
        this.play = play;
        if (play)
            repro.release();
    }


    @Override
    public void run() {
        while (true) {
            try {
                if (!play)
                    repro.acquire();
                notifyO();
                sleep(5000);
            } catch (InterruptedException ex) {
                Logger.getLogger(Processor.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private void notifyO() {
        if (observer != null) {
            observer.update(null, Notify.Processing);
        }
    }

    public void addObserver(Observer o) {
        observer = o;
    }

}
