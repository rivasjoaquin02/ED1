package Kernel;

import Ox.OperativeSystem;
import Ox.Process;
import TDA.*;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.image.BufferedImage;
import java.util.Observable;
import java.util.Observer;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 * Centro de Estudios de Matemática Computacional(CEMC-UCI)
 *
 * @author yadian
 * @date 22-sep-2014
 */
public class CemcOX extends java.awt.Canvas implements Observer {

    OperativeSystem system;
    private int _width, _height, _cpuW, _cpuH, _startRecCPU;
    private int newProcess;
    private Font number = new Font("TimesRoman", Font.PLAIN, 20);
    private Font info = new Font("TimesRoman", Font.PLAIN, 12);
    private Font time = new Font("TimesRoman", Font.PLAIN, 11);
    private Font numberNew = new Font("TimesRoman", Font.PLAIN, 100);
    private int current_id;
    private Process _processOK;
    private Observer observer;

    public CemcOX() {
        setBackground(Color.WHITE);
        system = new OperativeSystem();
        newProcess = -1;
        setSize(100, 100);
        current_id = 0;
    }

    public void addObserver(Observer o) {
        this.observer = o;
    }

    private void notifyO() {
        if (observer != null) {
            observer.update(null, Notify.Error);
        }
    }

    @Override
    public void update(Graphics g) {
        try {
            _width = this.getWidth();
            _height = this.getHeight();
            _cpuW = _width - 20;
            _cpuH = (int) (_height * 0.70) - 10;
            if ((system.ProcessRequest() / 10) * 80 > _cpuH) {
                this.setSize(_width, _height + 80);

                return;
            }
            _startRecCPU = _height - (_cpuH + 10);
            BufferedImage imagenBuffer = new BufferedImage(_width, _height, BufferedImage.TYPE_INT_RGB);
            Graphics2D gImage = (Graphics2D) imagenBuffer.getGraphics();
            gImage.setFont(number);
            gImage.setColor(Color.WHITE);
            gImage.fillRect(0, 0, _width, _height);
            drawCPU(gImage);
            drawProcessGenerator(gImage);
            drawProcess(gImage);
            g.drawImage(imagenBuffer, 0, 0, this);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
            notifyO();
        }
    }

    @Override
    public void paint(Graphics g) {
        update(g);
    }

    private void drawCPU(Graphics2D g) {

        g.setColor(Color.CYAN);
        g.fillRect(10, _startRecCPU, _cpuW, _cpuH);
        g.setColor(Color.BLACK);
        g.drawRect(10, _startRecCPU, _cpuW, _cpuH);
        g.setFont(info);
        g.drawString("Process Request", _width - 120, _startRecCPU + _cpuH - 10);
    }

    private void drawProcessGenerator(Graphics2D g) {
        g.setColor(new Color(195, 249, 222));
        g.fillRect(_width - 350, 10, 340, _startRecCPU - 20);
        g.setColor(Color.BLACK);
        g.drawRect(_width - 350, 10, 340, _startRecCPU - 20);
        g.setFont(info);
        g.drawString("New Process", _width - 120, _startRecCPU - 20);

        g.setColor(new Color(255, 204, 204));
        g.fillRect(10, 10, 520, _startRecCPU - 20);
        g.setColor(Color.BLACK);
        g.drawRect(10, 10, 520, _startRecCPU - 20);

        g.drawString("Run Process", 440, _startRecCPU - 20);

        if (newProcess > 0) {
            g.setFont(numberNew);
            g.setColor(Color.red);
            g.drawString(newProcess + "", _width - 230, 130);
            g.setFont(number);
        }
        if (_processOK != null) {
            _processOK.Play(false);
            g.setFont(numberNew);
            g.setColor(Color.BLACK);
            g.drawString(_processOK.getPriority() + "", 200, 130);
            g.setFont(info);
            g.drawString(_processOK.getWaitTime() + "", 300, 150);
            g.setFont(number);
        }
    }

    private void drawProcess(Graphics2D gImage) throws Exception {
        drawHead(gImage);
        int w = (_cpuW - 11 * 30) / 10;
        int h = 40;
        int row = 0;
        int col = 0;
        int cant = system.ProcessRequest();
        for (int i = 0; i < cant; i++) {

            int yr = row * (h + 40) + _startRecCPU + 50;
            int xr = col * (w + 30) + 40;
            drawNode(xr, yr, w, h, system.getProcess(i), gImage);
            int end = xr + w;

            if (col < 9) {
                drawRigthArrow(end, yr + 10, gImage);
            } else {
                gImage.drawLine(end - 5, yr + 20, end + 33, yr + 20);
                if (i == cant - 1) {
                    drawRigthArrow(15, yr + 90, gImage);
                }
            }
            if (col == 0 && row != 0) {
                drawRigthArrow(15, yr + 10, gImage);
            }
            if (++col == 10) {
                row++;
                col = 0;
            }
        }
        int yr = row * (h + 40) + _startRecCPU + 50;
        int xr = col * (w + 30) + 40;
        gImage.setColor(Color.WHITE);
        gImage.fillOval(xr, yr, 40, 40);
        gImage.setColor(Color.BLACK);
        gImage.drawOval(xr, yr, 40, 40);
        gImage.setColor(Color.BLUE);
        gImage.drawString("null", xr + 7, yr + 27);
    }

    private void drawNode(int xr, int yr, int w, int h, Process value, Graphics2D gImage) {
        if (value.isFirstTime()) {
            gImage.setColor(Color.RED);
            value.setFirstTime(false);
        } else {
            gImage.setColor(Color.ORANGE);
        }
        gImage.fillRect(xr, yr, w, h);
        gImage.setColor(Color.LIGHT_GRAY);
        gImage.fillRect(xr + 40, yr, 14, h);
        gImage.setColor(Color.BLACK);
        gImage.drawRect(xr + 40, yr, 14, h);
        gImage.drawRect(xr, yr, w, h);

        gImage.setFont(number);
        gImage.drawString(value.toString(), xr + 10, yr + 27);
        gImage.setFont(time);
        gImage.drawString(value.getWaitTime() + "", xr + 28, yr + 37);

    }

    private void drawLeftArrow(int x, int y, Graphics2D gImage) {
        gImage.drawLine(x, y + 30, x + 30, y + 30);
        //arrows
        int[] arrowX =
                {
                        x + 10, x, x + 10
                };
        int[] arrowY =
                {
                        y + 25, y + 30, y + 35
                };
        gImage.fillPolygon(new Polygon(arrowX, arrowY, 3));
    }

    private void drawRigthArrow(int x, int y, Graphics2D gImage) {

        gImage.drawLine(x - 5, y + 10, x + 30, y + 10);
        //arrows
        int[] arrowX =
                {
                        x + 20, x + 30, x + 20
                };
        int[] arrowY =
                {
                        y + 5, y + 10, y + 15
                };
        gImage.fillPolygon(new Polygon(arrowX, arrowY, 3));
    }

    private void drawHead(Graphics2D gImage) {
        //gImage.drawLine(30, y + 10, x + 30, y + 10);
        //arrows

        int[] arrowX =
                {
                        37, 67, 97
                };
        int[] arrowY =
                {
                        _startRecCPU + 10, _startRecCPU + 40, _startRecCPU + 10
                };
        gImage.setColor(Color.GREEN);
        gImage.fillPolygon(new Polygon(arrowX, arrowY, 3));
        gImage.setColor(Color.BLACK);
        gImage.drawPolygon(new Polygon(arrowX, arrowY, 3));
    }

    public void addProcess(int number) {
        newProcess = number;
        try {
            synchronized (system) {
                Process p = new Process(newProcess, current_id++);
                p.addObserver(this);
                system.newProcess(p);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
            notifyO();
        }
    }

    int getProcessCount() {
        return system.ProcessRequest();
    }

    public void Processing() throws Exception {
        try {
            synchronized (system) {
                if (system.ProcessRequest() != 0) {
                    system.runProcess();
                }
            }
        } catch (Exception ex) {
            notifyO();
            JOptionPane.showMessageDialog(null, ex);

        }
    }

    @Override
    public void update(Observable o, Object arg) {
        if (arg instanceof Process) {
            _processOK = ((Process) arg);
            _processOK.Play(false);
        }
    }

    public ListaSE<Process> getProcess() {
        return system.getALLProcess();
    }
}
