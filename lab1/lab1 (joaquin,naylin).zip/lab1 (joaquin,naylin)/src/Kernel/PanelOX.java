package Kernel;

import TDA.ListaSE;
import java.awt.BorderLayout;
import java.util.Observable;
import java.util.Observer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import Ox.Process;

/**
 * Centro de Estudios de Matemática Computacional(CEMC-UCI)
 *
 * @date 23-sep-2014
 * @author yadian
 */
public class PanelOX extends JPanel implements Observer
{

    private CemcOX cemcOX;
    private ProcessGenerator generator;
    private Processor processor;
    private boolean consume = false;

    public PanelOX()
    {
        setLayout(new BorderLayout());
        cemcOX = new CemcOX();
        cemcOX.addObserver(this);
        add(cemcOX, BorderLayout.CENTER);
        generator = new ProcessGenerator(3000);
        generator.addObserver(this);
        generator.start();

        processor = new Processor();
        processor.addObserver(this);
        processor.start();

        new Thread()
        {

            @Override
            public void run()
            {
                try
                {
                    while (true)
                    {
                        cemcOX.repaint();
                        sleep(1000);
                    }

                } catch (InterruptedException ex)
                {
                    Logger.getLogger(PanelOX.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }.start();
    }

    public void Play(boolean play) throws Exception
    {
        generator.setPlay(play);
        if (consume)
        {
            processor.setPlay(play);
        }
        ListaSE<Process> l = cemcOX.getProcess();
        synchronized (l)
        {

            for (int i = 0; i < l.Longitud(); i++)
            {
                l.Obtener(i).Play(play);
            }
        }
    }

    public void Consume(boolean value)
    {
        this.consume = value;
        processor.setPlay(value);

    }

    @Override
    public void update(Observable o, Object arg)
    {
        try
        {
            if (arg instanceof Integer)
            {
                cemcOX.addProcess((Integer) arg);

                if (cemcOX.getProcessCount() == 50)
                {
                    generator.setPlay(false);
                }
            } else if (arg instanceof Notify)
            {
                if (((Notify) arg) == Notify.Processing)
                {
                    cemcOX.Processing();
                } else
                {
                    Play(false);
                }
            }
        } catch (Exception ex)
        {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

}
