package TDA;

import java.util.Iterator;

/**
 * Centro de Estudios de Matemática Computacional(CEMC-UCI)
 *
 * @author yadian
 * @date 22-sep-2014
 */

public class ListaSE<T extends Comparable> implements ILista<T>, Iterable<T> {

    NodoSE<T> cabeza;

    public ListaSE() {
        cabeza = null;
    }

    // by STRANGE
    public void Adicionar(T data) {

        if (cabeza == null) {
            cabeza = new NodoSE<>(data, null);
            return;
        }

        NodoSE<T> trav = cabeza;
        while (trav.getSiguiente() != null) {
            // el dato del siguiente es menor que el nuevo dato
            if (trav.getSiguiente().getDato().compareTo(data) < 0) {
                trav.setSiguiente(
                        new NodoSE<>(data, trav.getSiguiente()));
                return;
            }
            trav = trav.getSiguiente();
        }

        // si se anade al final
        trav.setSiguiente(new NodoSE<>(data, null));
    }

    /*Ejercicio 2.

     */
    public T ObtenerPrimero() throws Exception {
        if (cabeza == null) {
            throw new Exception("La lista esta vacia");
        }
        T data = cabeza.getDato();
        cabeza = cabeza.getSiguiente();
        return data;
    }

    // by STRANGE
    @Override
    public void Eliminar(int pos) throws Exception {
        if (cabeza == null)
            throw new Exception("Lista esta vacia");

        if (pos > Longitud())
            throw new IllegalArgumentException("Posicion fuera de limites");

        //eliminar el 1ro
        if (pos == 1) {
            cabeza = cabeza.getSiguiente();
            return;
        }

        NodoSE<T> trav = cabeza;
        for (int i = 1; i < pos - 1; i++)
            trav = trav.getSiguiente();

        // mi sucesor sera el sucesor de mi sucesor
        trav.setSiguiente(trav.getSiguiente().getSiguiente());
    }

    @Override
    public void Insertar(T x, int pos) throws Exception {
        throw new Exception("Not Supported");
    }

    @Override
    public int Longitud() {
        if (cabeza == null) {
            return 0;
        } else {
            int longitud = 1;
            NodoSE<T> cursor = cabeza;
            while (cursor.getSiguiente() != null) {
                cursor = cursor.getSiguiente();
                longitud++;

            }
            return longitud;
        }
    }

    @Override
    public T Obtener(int pos) throws Exception {
        if (cabeza == null) {
            throw new Exception("Lista Vacía, la pos no existe");
        }
        if (pos < 0 && pos > Longitud() - 1) {
            throw new Exception("Posición fuera de rango");
        } else {
            NodoSE<T> cursor = cabeza;
            int cont = 0;
            while (cont++ < pos) {
                cursor = cursor.getSiguiente();

            }

            return cursor.getDato();
        }

    }


    @Override
    public Iterator<T> iterator() {
        return new Iterator<T>() {
            NodoSE<T> trav = cabeza;

            @Override
            public boolean hasNext() {
                return trav.getSiguiente() != null;
            }

            @Override
            public T next() {
                trav = trav.getSiguiente();
                return trav.getDato();
            }
        };
    }
}
