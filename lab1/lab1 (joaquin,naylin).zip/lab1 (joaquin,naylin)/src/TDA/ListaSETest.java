package TDA;

class ListaSETest {

    public static void main(String[] args) {
//        addTest();
        eliminarTest();
    }
    private static void addTest() {
        ListaSE <Integer> list = new ListaSE<>();

        list.Adicionar(5);
        list.Adicionar(3);
        list.Adicionar(2);
        list.Adicionar(1);
        list.Adicionar(4);

        System.out.println(list);
        //probar limites
    }

    private static void eliminarTest(){
        ListaSE <Integer> list = new ListaSE<>();

        list.Adicionar(5);
        list.Adicionar(3);
        list.Adicionar(2);
        list.Adicionar(1);
        list.Adicionar(4);

        try {
            list.Eliminar(5);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        //probar limites

    }
}