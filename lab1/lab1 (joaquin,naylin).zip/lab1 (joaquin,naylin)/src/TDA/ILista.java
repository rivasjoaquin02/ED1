package TDA;

/**
 * Centro de Estudios de Matemática Computacional(CEMC-UCI)
 *
 * @author yadian
 * @date 22-sep-2014
 */
public interface ILista<T> {
    public int Longitud();

    public void Adicionar(T x) throws Exception;

    public void Insertar(T x, int pos) throws Exception;

    public void Eliminar(int pos) throws Exception;

    public T Obtener(int pos) throws Exception;

}
